# Authors

## Original Authors

* [pyqode.qt](https://github.com/pyQode/pyqode.qt): Colin Duquesnoy ([@ColinDuquesnoy](https://github.com/ColinDuquesnoy))
* [spyderlib.qt](https://github.com/spyder-ide/spyder/commits/2.3/spyderlib/qt): Pierre Raybaut ([@PierreRaybaut](https://github.com/PierreRaybaut))
* [qt-helpers](https://github.com/glue-viz/qt-helpers): Thomas Robitaille ([@astrofrog](https://www.github.com/astrofrog))


## Current Maintainers

* Daniel Althviz ([@dalthviz](https://github.com/dalthviz))
* Carlos Cordoba ([@ccordoba12](https://github.com/ccordoba12))
* C.A.M. Gerlach ([@CAM-Gerlach](https://github.com/CAM-Gerlach))
* Spyder Development Team ([Spyder-IDE](https://github.com/spyder-ide))


## Contributors

* [The QtPy Contributors](https://github.com/spyder-ide/qtpy/graphs/contributors)
